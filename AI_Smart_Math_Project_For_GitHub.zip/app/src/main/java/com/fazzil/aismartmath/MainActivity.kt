package com.fazzil.aismartmath

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToLong

private val Blue = Color(0xFF2563EB)
private val Ink = Color(0xFF172554)
private val Page = Color(0xFFF3F6FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Page)) {
            SmartMathApp()
        } }
    }
}

data class StudyRecord(val question: String, val answer: String, val date: String)

class MathViewModel : ViewModel() {
    var question by mutableStateOf("")
    var result by mutableStateOf("")
    var records by mutableStateOf(listOf<StudyRecord>())
    var level by mutableStateOf("Sedang")
    var quizIndex by mutableIntStateOf(0)
    var score by mutableIntStateOf(0)
    var quizDone by mutableStateOf(false)

    fun solve() {
        val input = question.trim()
        if (input.isBlank()) { result = "Masukkan soal terlebih dahulu."; return }
        try {
            val value = ArithmeticParser(input).parse()
            val answer = if (value % 1.0 == 0.0) value.toLong().toString()
                         else String.format(Locale.US, "%.6f", value).trimEnd('0').trimEnd('.')
            result = "Konsep: operasi hitung campuran\nRumus: kerjakan kurung, lalu perkalian/pembagian, kemudian penjumlahan/pengurangan.\n\nLangkah:\n1. Periksa tanda kurung.\n2. Selesaikan perkalian dan pembagian dari kiri ke kanan.\n3. Selesaikan penjumlahan dan pengurangan dari kiri ke kanan.\n\nJawaban akhir: $answer\n\nCatatan: solver lokal ini mendukung operasi aritmetika dasar. Untuk aljabar, geometri, dan soal uraian dibutuhkan backend AI."
            records = listOf(StudyRecord(input, answer, SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id")).format(Date()))) + records
        } catch (_: Exception) {
            result = "Soal belum dapat dibaca. Gunakan angka, +, -, *, /, dan tanda kurung. Contoh: (12 + 8) * 3"
        }
    }

    fun nextQuiz(correct: Boolean) {
        if (correct) score++
        quizIndex++
        if (quizIndex >= quizQuestions.size) quizDone = true
    }
}

private class ArithmeticParser(source: String) {
    private val s = source.replace("×", "*").replace("÷", "/").replace(" ", "")
    private var i = 0
    fun parse(): Double { val v = expression(); require(i == s.length); require(v.isFinite()); return v }
    private fun expression(): Double {
        var v = term()
        while (i < s.length && (s[i] == '+' || s[i] == '-')) {
            val op = s[i++]; val n = term(); v = if (op == '+') v + n else v - n
        }
        return v
    }
    private fun term(): Double {
        var v = factor()
        while (i < s.length && (s[i] == '*' || s[i] == '/')) {
            val op = s[i++]; val n = factor()
            require(op != '/' || n != 0.0)
            v = if (op == '*') v * n else v / n
        }
        return v
    }
    private fun factor(): Double {
        require(i < s.length)
        if (s[i] == '+') { i++; return factor() }
        if (s[i] == '-') { i++; return -factor() }
        if (s[i] == '(') { i++; val v = expression(); require(i < s.length && s[i] == ')'); i++; return v }
        val start = i
        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        require(i > start)
        return s.substring(start, i).toDouble()
    }
}

private data class QuizQuestion(val prompt: String, val options: List<String>, val answer: Int, val explanation: String)
private val quizQuestions = listOf(
    QuizQuestion("Hasil dari 15 + 7 × 2 adalah ...", listOf("44", "29", "30", "22"), 1, "Perkalian dikerjakan lebih dahulu: 7 × 2 = 14, lalu 15 + 14 = 29."),
    QuizQuestion("Jika 3x = 21, nilai x adalah ...", listOf("6", "7", "8", "9"), 1, "Bagi kedua ruas dengan 3: x = 21 ÷ 3 = 7."),
    QuizQuestion("Luas persegi dengan sisi 8 cm adalah ...", listOf("16 cm²", "32 cm²", "64 cm²", "80 cm²"), 2, "Luas persegi = sisi × sisi = 8 × 8 = 64 cm².")
)

@Composable
fun SmartMathApp(vm: MathViewModel = viewModel()) {
    var page by remember { mutableStateOf("Beranda") }
    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("Beranda", "Solver", "Latihan", "Riwayat", "Profil").forEach { item ->
                    NavigationBarItem(selected = page == item, onClick = { page = item },
                        icon = { Icon(when(item) {
                            "Beranda" -> Icons.Default.Home
                            "Solver" -> Icons.Default.Calculate
                            "Latihan" -> Icons.Default.Quiz
                            "Riwayat" -> Icons.Default.History
                            else -> Icons.Default.Person
                        }, contentDescription = item) }, label = { Text(item) })
                }
            }
        },
        containerColor = Page
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            when(page) {
                "Beranda" -> HomePage(onOpen = { page = it })
                "Solver" -> SolverPage(vm)
                "Latihan" -> QuizPage(vm)
                "Riwayat" -> HistoryPage(vm)
                else -> ProfilePage()
            }
        }
    }
}

@Composable
private fun HomePage(onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().background(Page)) {
        Column(Modifier.fillMaxWidth().background(Blue, RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)).padding(22.dp)) {
            Text("AI SMART MATH", color = Color.White.copy(.85f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("Belajar jadi lebih mudah.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Pahami prosesnya, bukan hanya hasilnya.", color = Color.White.copy(.9f), fontSize = 13.sp)
            Spacer(Modifier.height(18.dp))
            Text("Asisten belajar matematika", color = Color.White, fontSize = 16.sp)
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Fitur utama", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            FeatureCard("AI Math Solver", "Hitung soal dan lihat langkah penyelesaian.", Icons.Default.Calculate) { onOpen("Solver") }
            FeatureCard("Daily Math Test", "Latihan pilihan ganda dan evaluasi nilai.", Icons.Default.Quiz) { onOpen("Latihan") }
            FeatureCard("Riwayat belajar", "Lihat soal yang pernah kamu kerjakan.", Icons.Default.History) { onOpen("Riwayat") }
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(15.dp)) {
                    Text("Fitur lanjutan", fontWeight = FontWeight.Bold, color = Ink)
                    Text("Pemindai kamera/OCR, AI generatif online, dan floating assistant memerlukan konfigurasi tambahan.", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun FeatureCard(title: String, desc: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }, shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Color(0xFFEAF1FF), shape = RoundedCornerShape(13.dp), modifier = Modifier.size(48.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(icon, contentDescription = null, tint = Blue) }
            }
            Column(Modifier.weight(1f).padding(start = 13.dp)) {
                Text(title, fontWeight = FontWeight.Bold, color = Ink)
                Text(desc, color = Color.Gray, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Blue)
        }
    }
}

@Composable
private fun SolverPage(vm: MathViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("AI Math Solver", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Masukkan operasi matematika dasar.", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = vm.question, onValueChange = { vm.question = it },
            modifier = Modifier.fillMaxWidth(), minLines = 3,
            label = { Text("Tulis soal matematika") },
            placeholder = { Text("Contoh: (15 + 5) * 3") })
        Button(onClick = { vm.solve() }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
            shape = RoundedCornerShape(13.dp)) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Selesaikan soal") }
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Penjelasan", fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(8.dp))
                Text(vm.result.ifBlank { "Hasil dan langkah penyelesaian akan muncul di sini." }, fontSize = 14.sp, lineHeight = 21.sp)
            }
        }
    }
}

@Composable
private fun QuizPage(vm: MathViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Daily Math Test", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(12.dp))
        if (vm.quizDone) {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Latihan selesai", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Nilai kamu: ${vm.score * 100 / quizQuestions.size}")
                    Button(onClick = { vm.quizIndex = 0; vm.score = 0; vm.quizDone = false }) { Text("Ulangi latihan") }
                }
            }
        } else {
            val q = quizQuestions[vm.quizIndex]
            var selected by remember(vm.quizIndex) { mutableIntStateOf(-1) }
            var submitted by remember(vm.quizIndex) { mutableStateOf(false) }
            Text("Soal ${vm.quizIndex + 1} dari ${quizQuestions.size}", color = Color.Gray)
            LinearProgressIndicator(progress = { (vm.quizIndex + 1f) / quizQuestions.size }, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(17.dp)) {
                    Text(q.prompt, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(12.dp))
                    q.options.forEachIndexed { idx, option ->
                        Row(Modifier.fillMaxWidth().clickable(enabled = !submitted) { selected = idx }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected == idx, onClick = { if (!submitted) selected = idx }, enabled = !submitted)
                            Text("${'A' + idx}. $option")
                        }
                    }
                    if (submitted) {
                        Text(if (selected == q.answer) "Benar!" else "Belum tepat.", color = if(selected == q.answer) Color(0xFF15803D) else Color(0xFFB45309), fontWeight = FontWeight.Bold)
                        Text(q.explanation, fontSize = 13.sp)
                        Button(onClick = { vm.nextQuiz(selected == q.answer) }, modifier = Modifier.fillMaxWidth()) { Text(if(vm.quizIndex == quizQuestions.lastIndex) "Lihat nilai" else "Soal berikutnya") }
                    } else {
                        Button(onClick = { if(selected >= 0) submitted = true }, enabled = selected >= 0, modifier = Modifier.fillMaxWidth()) { Text("Periksa jawaban") }
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryPage(vm: MathViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Riwayat belajar", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
            TextButton(onClick = { vm.records = emptyList() }) { Text("Hapus") }
        }
        if(vm.records.isEmpty()) Text("Belum ada riwayat. Selesaikan soal di Math Solver terlebih dahulu.", color = Color.Gray)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(vm.records) { r ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(r.question, fontWeight = FontWeight.Bold)
                        Text("Jawaban: ${r.answer}", color = Blue)
                        Text(r.date, color = Color.Gray, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfilePage() {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Profil & Pengaturan", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("AI Smart Math Assistant", fontWeight = FontWeight.Bold)
                Text("Versi 1.0 • Prototipe belajar", color = Color.Gray, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Text("Privasi: aplikasi ini tidak membaca layar atau data aplikasi lain.")
                Text("AI online, login, sinkronisasi cloud, OCR kamera, dan floating assistant belum aktif pada build ini.", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}
