# AI Smart Math Assistant - Native Android MVP

## Yang sudah aktif
- Aplikasi native Kotlin + Jetpack Compose + Material 3.
- Navigasi Beranda, Solver, Latihan, Riwayat, Profil.
- Solver offline untuk operasi aritmetika dasar dengan kurung dan urutan operasi.
- Penjelasan langkah umum dan hasil.
- Kuis pilihan ganda dengan pemeriksaan jawaban, penjelasan, dan nilai.
- Riwayat lokal selama aplikasi berjalan.

## Belum aktif / perlu implementasi lanjutan
OCR kamera/galeri (ML Kit + CameraX), AI generatif melalui backend HTTPS, login/register, Room persistence, timer kuis, dan floating overlay service. Dependency dasarnya sudah disiapkan untuk Room, Retrofit, ML Kit, dan CameraX, tetapi belum dihubungkan ke layar. Jangan menganggap fitur tersebut telah tersedia.

## Build APK
1. Buka folder ini di Android Studio.
2. Instal Android SDK Platform 35 dan JDK 17.
3. Tunggu Gradle Sync.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Integrasi AI aman
Buat backend HTTPS sendiri. Simpan API key di server, bukan di APK. Aplikasi Android harus mengirim soal ke endpoint backend milikmu. Tambahkan autentikasi, batas pemakaian, validasi input, dan kebijakan privasi sebelum dipakai publik.
